import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

const TenantList = () => {
    const [properties, setProperties] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            navigate('/login');
        } else {
            fetchProperties();
        }
    }, [navigate]);

    const fetchProperties = async () => {
        try {
            const response = await axios.get('http://127.0.0.1:8000/api/properties/', {
                headers: { Authorization: `Token ${localStorage.getItem('token')}` },
            });
            setProperties(response.data);
        } catch (error) {
            console.error('Error fetching properties:', error);
        }
    };

    const handleBook = async (propertyId) => {
        try {
            await axios.post(
                'http://127.0.0.1:8000/api/bookings/',
                { property: propertyId, start_date: '2023-10-01', end_date: '2023-10-10' }, // Example dates
                { headers: { Authorization: `Token ${localStorage.getItem('token')}` } }
            );
            alert('Booking successful!');
        } catch (error) {
            console.error('Error booking property:', error);
        }
    };

    const filteredProperties = properties.filter(property =>
        property.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="container mt-5">
            <h1 className="text-center mb-4">Welcome, Tenant!</h1>
            <p className="text-center">
                Here’s what you can do:
            </p>

            {/* Search Properties */}
            <div className="mb-4">
                <h2>Search Properties</h2>
                <input
                    type="text"
                    placeholder="Search properties..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="form-control mb-3"
                />
                <div className="row">
                    {filteredProperties.map(property => (
                        <div key={property.id} className="col-md-4 mb-4">
                            <div className="card">
                                <img
                                    src={property.image ? `http://127.0.0.1:8000${property.image}` : 'https://via.placeholder.com/300'}
                                    className="card-img-top"
                                    alt={property.name}
                                />
                                <div className="card-body">
                                    <h5 className="card-title">{property.name}</h5>
                                    <p className="card-text">{property.description}</p>
                                    <p className="card-text"><strong>Price:</strong> ${property.price}</p>
                                    <button
                                        onClick={() => handleBook(property.id)}
                                        className="btn btn-primary"
                                    >
                                        Book
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Manage Reservations */}
            <div className="mt-5">
                <h2>Manage Reservations</h2>
                <p>View and manage your bookings here.</p>
                <Link to="/reservations" className="btn btn-success">
                    View Reservations
                </Link>
            </div>
        </div>
    );
};

export default TenantList;